document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("uploadForm");
    const imageInput = document.getElementById("imageInput");
    const preview = document.getElementById("preview");
    const resultDiv = document.getElementById("result");

    // 🔹 Image Preview
    imageInput.addEventListener("change", function () {
        const file = imageInput.files[0];

        if (!file) return;

        // Validate image type
        if (!file.type.startsWith("image/")) {
            alert("Please upload a valid image file.");
            imageInput.value = "";
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            preview.src = e.target.result;
            preview.style.display = "block";
        };
        reader.readAsDataURL(file);
    });

    // 🔹 Handle Form Submit (AJAX)
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const file = imageInput.files[0];
        if (!file) {
            alert("Please select an image first.");
            return;
        }

        const formData = new FormData();
        formData.append("image", file);

        // CSRF Token
        const csrfToken = document.querySelector("[name=csrfmiddlewaretoken]").value;

        resultDiv.innerHTML = "Processing...";
        resultDiv.style.color = "blue";

        fetch("", {
            method: "POST",
            headers: {
                "X-CSRFToken": csrfToken
            },
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            // Reload page content with prediction
            document.open();
            document.write(data);
            document.close();
        })
        .catch(error => {
            resultDiv.innerHTML = "Error occurred!";
            resultDiv.style.color = "red";
            console.error("Error:", error);
        });
    });

});