import os
import numpy as np
from django.shortcuts import render
from django.conf import settings
from tensorflow.keras.models import load_model
import cv2

# Professional path handling
model_path = "E:\Django\Ai_application\Ai_project\Ai_project\model\model.h5"
model = load_model(model_path)

def home(request):

    predicted_class = None   # ✅ Add this

    if request.method == "POST" and request.FILES.get('image'):

        uploaded_file = request.FILES['image']

        file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
        img = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)

        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, (128, 128))

        img = img.astype("float32") / 255.0
        img = np.expand_dims(img, axis=0)

        prediction = model.predict(img)
        prediction_result = int(np.argmax(prediction))

        classed = ['Buildings', 'Forest', 'Glacier', 'Mountain', 'Sea', 'Street']

        predicted_class = classed[prediction_result]

    return render(request, "home.html", {
        "prediction": predicted_class
    })