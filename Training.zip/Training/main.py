import numpy as np 
import cv2
import os 
from sklearn.preprocessing import LabelEncoder

labels,images=[],[]

fol_dir="Dataset/seg_train/seg_train"

labels,images=[],[]

fold_list=os.listdir(fol_dir)

for fold_names in fold_list:
    sub_dir=os.path.join(fol_dir,fold_names)
    images_list=os.listdir(sub_dir)
    for image_name in images_list:
        image_dir=os.path.join(sub_dir,image_name)
        image=cv2.imread(image_dir)
        # print(image.dtype)
        # print(np.unique(image))
        normalized_image=cv2.resize(image,(128,128)).astype('float32')/255
        # print(normalized_image.dtype)
        # print(normalized_image.shape)
        images.append(normalized_image)
        labels.append(fold_names)
        
# np.save("images.npy",images)
# np.save("lables.npy",labels)

images=np.load("images.npy")
labels=np.load("lables.npy")


lb=LabelEncoder()
normalized_labels=lb.fit_transform(labels).astype('int32')

# for k in np.unique(normalized_labels):
#     print(k,"         ",np.sum(normalized_labels == k))


import tensorflow as tf  
from keras import layers
from keras.models import Model
from sklearn.model_selection import train_test_split


x_train,x_test,y_train,y_test=train_test_split(images,normalized_labels,test_size=0.2,random_state=42)

def class_model(x_train,y_train):
    input_layer=layers.Input((x_train[0].shape))
    
    x=layers.Conv2D(32,(3,3), activation='relu')(input_layer)
    x=layers.MaxPooling2D((2,2))(x)
    
    
    x=layers.Conv2D(64,(3,3), activation='relu')(x)
    x=layers.MaxPooling2D((2,2))(x)
    
    x=layers.Conv2D(128,(3,3), activation='relu')(x)
    x=layers.MaxPooling2D((2,2))(x)
    
    x=layers.Conv2D(256,(3,3), activation='relu')(x)
    x=layers.MaxPooling2D((2,2))(x)
    
    x=layers.Flatten()(x)
    x=layers.Dense(128,activation='relu')(x)
    
    output=layers.Dense(len(np.unique(y_train)),activation='softmax')(x)
    
    
    model=Model(inputs=input_layer,outputs=output)
    
    
    model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
    )
    
    
    model.fit(x_train,y_train,batch_size=32,verbose=1,epochs=100,validation_split=0.2)
    
    return model

 
trained_model=class_model(x_train, y_train)
# trained_model.save("model.h5")
    
    
    
    




        
        